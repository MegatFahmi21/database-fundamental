INSERT INTO Customer VALUES(32673898,'Harith Najmi',20,'M','Sepang,Selangor','1201101262@gmail.com','B2',982001908342)

INSERT INTO Customer VALUES(88821068,'Megat Fahmi',20,'M','Subang Jaya,Selangor','1201100484@gmail.com','B2',642155153101)

INSERT INTO Customer VALUES(51017229,'Mohd Fatih',24,'M','Tawau,Sabah','1201302166@gmail.com','B2',559891750151)

INSERT INTO Customer VALUES(96778994,'Muhammad Amin',22,'M','Jasin,Melaka','1211302855@gmail.com','B',271654148263)

INSERT INTO Customer VALUES(11508208,'Linda Chua',40,'F','Batu Pahat,Johor','lindachua40@yahoo.com','B',552690744138)

INSERT INTO Customer VALUES(37257858,'Farah Ann',33,'F','Sepang,Selangor','farahann33@hotmail.com','B',495165312825)

INSERT INTO Customer VALUES(64684865,'Goh Chien Lee',39,'M','Subang Jaya,Selangor','clgoh@yahoo.com','B2',960217657984)
--------------------------------------------------------------------

INSERT INTO Staff VALUES(1000,'Ali Abu',0123456789,'aliabu12@gmail.com')

INSERT INTO Staff VALUES(1029,'Killua Zoldyck',01264738290,'killuahxh@yahoo.com')

INSERT INTO Staff VALUES(1193,'Itachi Uchiha',0198624567,'itachisasuke@gmail.com')
-----------------------------------------------------------------------------------------------------------------------
INSERT INTO Membership VALUES(1722,50,32673898)	-harith

INSERT INTO Membership VALUES(7877,10,88821068)	-megat

INSERT INTO Membership VALUES(5797,105,11508208)	linda

INSERT INTO Membership VALUES(7477,88,37257858)	farah
-------------------------------------------------

INSERT INTO Promotions VALUES('SCR25','Y',1722,25.0)

INSERT INTO Promotions VALUES('SCR18','Y',7877,25.0)

INSERT INTO Promotions VALUES('SCR77','Y',5797,30.0)

INSERT INTO Promotions VALUES('SCR21','Y',7477,30.0)
-------------------------------------------------------

INSERT INTO Car VALUES(85728,'Honda','Sedan','WAA111',15000,'White',5,1000)			-FATIH         

INSERT INTO Car VALUES(16830,'BMW','SUV','WTE976',30000,'Black',5,1029)			- harith

INSERT INTO Car VALUES(84602,'PROTON','Sedan','JYJ4359',14000,'White',5,1000)		FARAH	     	

INSERT INTO Car VALUES(39621,'Toyata','MPV','JPC5600',21500,'Blue',7,1193)			AMIN

INSERT INTO Car VALUES(82868,'BMW','Coupe','TMJ1',19000,'Red',2,1193)			- megat	      

INSERT INTO Car VALUES(59353,'Proton','SUV','VCR1369',8800,'Black',5,1000)			LINDA

INSERT INTO Car VALUES(37340,'Toyota','Coupe','WWW14',14000,'Black',2,1029)			GOH
-------------------------------------------------------------------------------------


INSERT INTO Booking VALUES ('81A0438',32673898,16830,'09:30:00','10:25:00','2022-01-15','2022-01-30')

INSERT INTO Booking VALUES ('098SH77',88821068,82868,'08:00:00','9:17:00','2021-12-12','2022-01-01')

INSERT INTO Booking VALUES ('725TF71',51017229,85728,'15:15:00','17:45:00','2021-03-20','2021-03-23')

INSERT INTO Booking VALUES ('12333KS',96778994,39621,'11:55:00','12:20:00','2021-02-11','2021-02-15')

INSERT INTO Booking VALUES ('ASD234F',11508208,59353,'14:25:00','15:00:00','2022-01-01','2022-01-05')

INSERT INTO Booking VALUES ('MCNS6F7',37257858,84602,'10:30:00','10:45:00','2021-04-17','2021-04-19')

INSERT INTO Booking VALUES ('09997HF',64684865,37340,'13:10:00','14:00:00','2022-04-30','2022-05-01')





-------------------------------------------------------------------------------------------------------------------------------------------

INSERT INTO Billing VALUES(49768,'81A0438','SCR25','2022-01-11','11:45:00','DEBIT',1800)

INSERT INTO Billing VALUES(54558,'098SH77','SCR18','2021-12-10','09:30:00','CREDIT',2100)

INSERT INTO Billing VALUES(62742,'725TF71',null,'2021-03-19','20:15:00','CREDIT',300)

INSERT INTO Billing VALUES(77103,'12333KS',null,'2021-02-09','22:00:00','EWALLET',1250)

INSERT INTO Billing VALUES(60453,'ASD234F','SCR77','2021-12-31','07:20:00','EWALLET',575)

INSERT INTO Billing VALUES(16245,'MCNS6F7','SCR21','2021-04-15','12:30:00','CREDIT',250)

INSERT INTO Billing VALUES(19835,'09997HF',null,'2022-04-25','17:15:00','DEBIT',650)
------------------------------------------------------------------------------------------------------------------------

INSERT INTO Maintenance VALUES('2022-02-10','Putrajaya,Selangor',16830,1029)

INSERT INTO Maintenance VALUES('2022-01-05','Damansara,Selangor',82868,1193)

INSERT INTO Maintenance VALUES('2021-03-27','Tawau,Sabah',85728,1000)

INSERT INTO Maintenance VALUES('2021-02-20','Tangkak,Melaka',39621,1193)

INSERT INTO Maintenance VALUES('2022-01-10','Batu Pahat,Johor',59353,1000)

INSERT INTO Maintenance VALUES('2021-04-20','Putrajaya,Selangor',84602,1000)

INSERT INTO Maintenance VALUES('2022-05-03','Damansara,Selangor',37340,1029)