--1)Aggregate Function 
SELECT AVG (pay_ammount) AS AverageAmmount FROM Billing WHERE pay_type = 'DEBIT';
SELECT SUM (pay_ammount) AS SumAmmount FROM Billing WHERE pay_type = 'DEBIT' OR pay_type = 'EWALLET';

--2)Group by and Having Clauses
SELECT car_colour,count(car_colour) AS TOTAL FROM Car GROUP BY car_colour;
SELECT cust_age,Count(cust_age) as RepeatAge FROM Customer GROUP BY cust_age HAVING AVG(cust_age) < 35;

--3)Triggers
CREATE TRIGGER TrgPromo AFTER INSERT ON Promotions FOR EACH ROW mode db2sql UPDATE Promotions SET promotion_rate = promotion_rate + 1;

--5)View
CREATE VIEW AutoDrivers AS SELECT cust_ID,cust_name,cust_license FROM Customer WHERE cust_license = 'DA';

Select * from AutoDrivers;

--6)Subqueries/nested queries
SELECT billing_ID,pay_ammount FROM Billing WHERE pay_ammount > (SELECT AVG(pay_ammount) FROM Billing);

--7)Four Queries not covered in lecture
--i.Fetch
select * from Car FETCH FIRST 3 ROWS ONLY;
--ii.Select Distinct
SELECT (DISTINCT(cust_adress)) AS AllAdress FROM Customer UNION ALL SELECT (DISTINCT(location_maintenance)) FROM Maintenance;
--iii.Case
SELECT cust_name, cust_age, CASE WHEN cust_age > 33 THEN 'The customer age is greater than 33' 
WHEN cust_age = 33 THEN 'The customer age is 33' 
ELSE 'The customer age is under 30' END AS customer_ageText FROM Customer;
--iv.Limit
SELECT * FROM Customer WHERE cust_email LIKE '%gmail.com' LIMIT 2;




