CREATE TABLE Customer(cust_ID BIGINT PRIMARY KEY NOT NULL,cust_name VARCHAR(25),cust_age SMALLINT,cust_gender CHAR(1) CHECK (cust_gender IN ('F','M')),cust_adress VARCHAR(25),cust_email VARCHAR(30),cust_license VARCHAR(3),cust_bankinfos BIGINT)

CREATE TABLE Staff(staff_ID BIGINT PRIMARY KEY NOT NULL,staff_name VARCHAR(20),staff_phonenumber BIGINT,staff_email VARCHAR(30))

CREATE TABLE Membership(member_ID BIGINT PRIMARY KEY NOT NULL,member_points SMALLINT,cust_ID BIGINT,FOREIGN KEY(cust_ID)REFERENCES Customer)

CREATE TABLE Promotions(promotion_code VARCHAR(5) PRIMARY KEY NOT NULL,member_promotion CHAR(1) CHECK (member_promotion IN ('Y','N')),member_ID BIGINT ,promotion_rate DECIMAL(4,2),FOREIGN KEY (member_ID) REFERENCES Membership)

CREATE TABLE Car(car_ID BIGINT PRIMARY KEY NOT NULL,car_model VARCHAR(10),car_type VARCHAR(10) ,car_platenum VARCHAR(10),car_milleage BIGINT,car_colour VARCHAR(7),car_perPax SMALLINT,staff_ID SMALLINT, FOREIGN KEY(staff_ID)  REFERENCES Staff)

CREATE TABLE Booking(booking_ID VARCHAR(10)PRIMARY KEY NOT NULL,cust_ID BIGINT,car_ID BIGINT,time_arrive TIME,time_depart TIME,date_rent DATE,date_return DATE,FOREIGN KEY (cust_ID)REFERENCES Customer,FOREIGN KEY (car_ID)REFERENCES CAR)

CREATE TABLE Billing(billing_ID BIGINT PRIMARY KEY NOT NULL,booking_ID VARCHAR(10),promotion_code VARCHAR(5),pay_date DATE,pay_time TIME,pay_type VARCHAR(10),pay_ammount DECIMAL(6,2),FOREIGN KEY (booking_ID)REFERENCES Booking,FOREIGN KEY (promotion_code)REFERENCES Promotions)

CREATE TABLE Maintenance(date_maintenance DATE PRIMARY KEY NOT NULL,location_maintenance VARCHAR(20),car_ID BIGINT,staff_ID BIGINT,FOREIGN KEY(car_ID)REFERENCES Car,FOREIGN KEY (staff_ID)REFERENCES Staff)
