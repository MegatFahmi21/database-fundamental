--4) STORED PROCEDURES
CREATE PROCEDURE give_bonus(IN BONUS INT) BEGIN UPDATE Membership SET member_points = member_points + bonus;
end
Call give_bonus(10)
--This stored procedure will add an additional X points to all the member's points 
--inside the Membership table when called. The way to call the stored procedure is:
-- call give_bonus(x)
